#ifndef		__AI_H
#define		__AI_H

void	ai_init(uint8_t *kmodel_addr);
void	ai_run(obj_info_t *obj_info);

#endif

