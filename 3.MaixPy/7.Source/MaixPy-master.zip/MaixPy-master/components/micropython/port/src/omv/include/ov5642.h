#ifndef __OV5642__H__
#define __OV5642__H__

#include "sensor.h"
int ov5642_init(sensor_t *sensor);

#endif  //!__OV5642__H__