#ifndef __MOD_SPEECH_RECOGNIZER_H
#define __MOD_SPEECH_RECOGNIZER_H

#include "py/obj.h"

extern const mp_obj_type_t speech_isolated_word_type;
extern const mp_obj_type_t speech_asr_type;

#endif

