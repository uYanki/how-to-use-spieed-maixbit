#ifndef MICROPY_INCLUDED_K210_MOD_TEST_H
#define MICROPY_INCLUDED_K210_MOD_TEST_H

#include "py/obj.h"

extern const mp_obj_type_t app_test_type;

#endif /* MICROPY_INCLUDED_K210_MOD_TEST_H */