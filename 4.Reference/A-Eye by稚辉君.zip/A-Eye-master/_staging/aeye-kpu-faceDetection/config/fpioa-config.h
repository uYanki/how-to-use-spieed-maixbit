// DO NOT MODIFY THIS FILE, IT WILL BE OVERRIDE!!!
#ifndef _IDE_FPIOA_H
#define _IDE_FPIOA_H

int ide_config_fpioa();

#endif // _IDE_FPIOA_H
