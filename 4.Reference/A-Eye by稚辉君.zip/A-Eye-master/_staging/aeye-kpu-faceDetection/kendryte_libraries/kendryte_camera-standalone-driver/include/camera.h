#pragma once

#ifdef __cplusplus
extern "C" {
#endif

void camera_init();

#ifdef __cplusplus
} // extern "C" {
#endif
